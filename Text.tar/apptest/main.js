const express = require("express");
const fs = require('fs')
const app = express();
app.get("/", (req, res) => {
    res.send("Hello World!");
    console.log("Hellow World");
});
console.log("Started Continuous Counter")
app.listen(7070)
let count = 0
if (!fs.existsSync('./test.txt')) {
    fs.writeFileSync('./test.txt', count.toString(), { encoding: 'utf-8' })
}
setInterval(() => {
    let count = parseInt(fs.readFileSync('./test.txt', { encoding: 'utf-8' })) + 1
    console.log(count)
    fs.writeFileSync('./test.txt', count.toString(), { encoding: 'utf-8' })
}, 100);